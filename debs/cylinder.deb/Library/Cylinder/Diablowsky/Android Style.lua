--[[

Requested by /u/JoeB35 on reddit
~2zqa

]]--

return function(page, offset, screen_width)
    local percent = offset/page.width

    if percent < 0 then
        page:translate(offset, 0, -0.001)
        page:scale(1+percent/2)
        page.alpha = 1+percent
    end

end